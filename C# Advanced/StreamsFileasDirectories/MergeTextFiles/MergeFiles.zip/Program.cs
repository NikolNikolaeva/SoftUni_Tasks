﻿using System;
using System.Collections.Generic;
using System.IO;

namespace MergeFiles
{
    public class MergeFiles
    {
        static void Main()
        {
            var firstInputFilePath = @"..\..\..\Files\input1.txt";
            var secondInputFilePath = @"..\..\..\Files\input2.txt";
            var outputFilePath = @"..\..\..\Files\output.txt";
            MergeTextFiles(firstInputFilePath, secondInputFilePath, outputFilePath);
        }

        public static void MergeTextFiles(string firstInputFilePath, string secondInputFilePath, string outputFilePath)
        {
            using (StreamReader reader1 = new StreamReader(firstInputFilePath))
            {
                using (StreamReader reader2 = new StreamReader(secondInputFilePath))
                {
                    using (StreamWriter writer = new StreamWriter(outputFilePath))
                    {

                        string[] linesText1 = reader1.ReadLine().Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries);
                        string[] linesText2 = reader2.ReadLine().Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries);

                        int counterText1
                        for (int i = 0; i < linesText1.Length + linesText2.Length; i++)
                        {
                            if (i % 2 == 0)
                            {
                                writer.WriteLine()
                            }
                        }
                    }
                }
            }
        }
    }
}
